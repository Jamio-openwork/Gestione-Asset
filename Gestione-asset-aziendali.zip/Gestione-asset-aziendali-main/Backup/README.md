# Gestione asset aziendali
La soluzione di gestione Asset ha la finalità di mappare e gestire il ciclo di vita degli asset aziendali, ovvero tutti gli strumenti (es. dispositivi hardware, servizi, account) utilizzati all’interno di una qualsiasi organizzazione ed assegnati a specifici operatori.

PER MAGGIORI INFO: [Readme - Gestione Asset Aziendali.pdf](https://github.com/Jamio-openwork/Gestione-asset-aziendali/files/6856883/Readme.-.Gestione.Asset.Aziendali.pdf)

![PreviewReadme](https://user-images.githubusercontent.com/86653778/125311974-285e3800-e334-11eb-9e23-caea2f7c9ec6.png)
